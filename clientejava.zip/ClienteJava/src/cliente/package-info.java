@javax.xml.bind.annotation.XmlSchema(namespace = "http://control/")
package cliente;
