package cliente;
import java.util.Scanner;



public class Cliente {

public static void main(String[] args) {
	ValidaCNPJ ValidaCNPJ = new ValidaCNPJService().getValidaCNPJPort();
	
	Scanner ler = new Scanner(System.in);
	 
    String cnpj;
 
    System.out.printf("Informe um CNPJ: ");
    cnpj = ler.next();

    System.out.printf("" +ValidaCNPJ.isCNPJ(cnpj));
}}