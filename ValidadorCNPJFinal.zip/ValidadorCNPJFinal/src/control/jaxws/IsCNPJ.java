
package control.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "isCNPJ", namespace = "http://control/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "isCNPJ", namespace = "http://control/")
public class IsCNPJ {

    @XmlElement(name = "cnpj", namespace = "")
    private String cnpj;

    /**
     * 
     * @return
     *     returns String
     */
    public String getCnpj() {
        return this.cnpj;
    }

    /**
     * 
     * @param cnpj
     *     the value for the cnpj property
     */
    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

}
